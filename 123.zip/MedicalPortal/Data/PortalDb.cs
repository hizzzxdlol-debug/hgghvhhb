using MedicalPortalApp.Models;
using Microsoft.EntityFrameworkCore;

namespace MedicalPortalApp.Data;

/// <summary>Контекст базы данных SQLite.</summary>
public class PortalDb : DbContext
{
    public PortalDb(DbContextOptions<PortalDb> options) : base(options) { }

    public DbSet<Patient> Patients => Set<Patient>();
    public DbSet<Doctor> Doctors => Set<Doctor>();
    public DbSet<Department> Departments => Set<Department>();
    public DbSet<MedicalService> Services => Set<MedicalService>();
    public DbSet<Appointment> Appointments => Set<Appointment>();
    public DbSet<MedicalRecord> MedicalRecords => Set<MedicalRecord>();
    public DbSet<MedicalTest> MedicalTests => Set<MedicalTest>();
    public DbSet<Payment> Payments => Set<Payment>();
    public DbSet<Prescription> Prescriptions => Set<Prescription>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        // Patient и Doctor хранятся в одной таблице People (наследование от абстрактного Person)
        modelBuilder.Entity<Person>().ToTable("People");
        base.OnModelCreating(modelBuilder);
    }
}
