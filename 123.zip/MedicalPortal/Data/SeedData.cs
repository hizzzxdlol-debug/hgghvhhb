using MedicalPortalApp.Models;

namespace MedicalPortalApp.Data;

/// <summary>Начальные данные, чтобы сайт сразу можно было посмотреть и проверить.</summary>
public static class SeedData
{
    public static void Initialize(PortalDb db)
    {
        if (db.Doctors.Any() || db.Patients.Any()) return;

        // --- Отделения ---
        var therapy = new Department { DepartmentName = "Терапевтическое отделение", Floor = 1, PhoneNumber = "+7 7172 00-01-01" };
        var cardio = new Department { DepartmentName = "Кардиология", Floor = 2, PhoneNumber = "+7 7172 00-02-02" };
        var neuro = new Department { DepartmentName = "Неврология", Floor = 3, PhoneNumber = "+7 7172 00-03-03" };
        db.Departments.Add(therapy);
        db.Departments.Add(cardio);
        db.Departments.Add(neuro);
        db.SaveChanges();

        // --- Врачи ---
        var d1 = new Doctor { FullName = "Иванов Алексей Петрович", BirthDate = new DateTime(1980, 3, 12), Specialization = "Терапевт", Experience = 12, CabinetNumber = 101, Salary = 400000m };
        var d2 = new Doctor { FullName = "Сергеева Мария Олеговна", BirthDate = new DateTime(1985, 7, 21), Specialization = "Кардиолог", Experience = 8, CabinetNumber = 205, Salary = 450000m };
        var d3 = new Doctor { FullName = "Касымов Данияр Ерланович", BirthDate = new DateTime(1975, 11, 2), Specialization = "Невролог", Experience = 18, CabinetNumber = 312, Salary = 480000m };
        therapy.AddDoctor(d1);
        cardio.AddDoctor(d2);
        neuro.AddDoctor(d3);
        db.Doctors.Add(d1);
        db.Doctors.Add(d2);
        db.Doctors.Add(d3);
        db.SaveChanges();

        therapy.HeadDoctor = d1;
        cardio.HeadDoctor = d2;
        neuro.HeadDoctor = d3;
        db.SaveChanges();

        // --- Услуги ---
        var s1 = new MedicalService { ServiceName = "Консультация терапевта", Description = "Первичный приём", Price = 8000m, Duration = 30 };
        var s2 = new MedicalService { ServiceName = "ЭКГ", Description = "Электрокардиография", Price = 6000m, Duration = 20 };
        var s3 = new MedicalService { ServiceName = "МРТ головного мозга", Description = "Магнитно-резонансная томография", Price = 35000m, Duration = 40 };
        var s4 = new MedicalService { ServiceName = "Общий анализ крови", Description = "Забор и расшифровка", Price = 3000m, Duration = 15 };
        db.Services.Add(s1);
        db.Services.Add(s2);
        db.Services.Add(s3);
        db.Services.Add(s4);

        // --- Пациенты (медкарта создаётся вместе с пациентом — композиция) ---
        var p1 = NewPatient("Бекова Айгерим Нурлановна", new DateTime(1990, 5, 14), "+7 701 123 45 67", "aigerim@example.com", "г. Астана, ул. Кенесары, 10");
        var p2 = NewPatient("Омаров Руслан Сериков", new DateTime(1978, 9, 3), "+7 702 987 65 43", "ruslan@example.com", "г. Астана, пр. Туран, 25");
        var p3 = NewPatient("Ахметова Дана Маратовна", new DateTime(2001, 1, 27), "+7 705 555 12 34", "dana@example.com", "г. Астана, ул. Сыганак, 4");
        db.Patients.Add(p1);
        db.Patients.Add(p2);
        db.Patients.Add(p3);
        db.SaveChanges();

        p1.MedicalRecord!.AddDiagnosis("ОРВИ");
        p2.MedicalRecord!.UpdateHistory("Первичный осмотр, жалоб нет");

        // --- Завершённый приём в прошлом + оплата ---
        db.Appointments.Add(new Appointment
        {
            Patient = p1,
            Doctor = d1,
            MedicalService = s1,
            AppointmentDate = DateTime.Today.AddDays(-3),
            AppointmentTime = TimeSpan.FromHours(11),
            Status = AppointmentStatus.Completed
        });
        var paid = new Payment { Patient = p1, MedicalService = s1, Amount = s1.Price };
        paid.MakePayment();
        db.Payments.Add(paid);
        db.SaveChanges();

        // --- Будущий приём (через обычную проверку CreateAppointment) ---
        var doctorWithAppointments = db.Doctors.First(d => d.FullName == d2.FullName);
        var future = new Appointment
        {
            Patient = p2,
            Doctor = doctorWithAppointments,
            MedicalService = s2,
            AppointmentDate = DateTime.Today.AddDays(1),
            AppointmentTime = TimeSpan.FromHours(10)
        };
        var (ok, _) = future.CreateAppointment();
        if (ok)
        {
            db.Appointments.Add(future);
            db.SaveChanges();
        }

        db.MedicalTests.Add(new MedicalTest { Patient = p1, TestName = "Общий анализ крови", TestDate = DateTime.Today.AddDays(-3), Result = "В пределах нормы" });
        db.Prescriptions.Add(new Prescription { Patient = p1, Doctor = d1, MedicationName = "Парацетамол", Dosage = "500 мг, 2 раза в день", Duration = 5 });
        db.SaveChanges();
    }

    private static Patient NewPatient(string name, DateTime birth, string phone, string email, string address)
    {
        var p = new Patient { FullName = name, BirthDate = birth, PhoneNumber = phone, Email = email, Address = address };
        p.MedicalRecord = new MedicalRecord { Patient = p, CreationDate = DateTime.Now };
        return p;
    }
}
