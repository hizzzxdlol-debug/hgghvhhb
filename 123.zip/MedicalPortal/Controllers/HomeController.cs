using MedicalPortalApp.Services;
using Microsoft.AspNetCore.Mvc;

namespace MedicalPortalApp.Controllers;

public class HomeController : Controller
{
    private readonly MedicalPortal _portal;
    public HomeController(MedicalPortal portal) => _portal = portal;

    public IActionResult Index()
    {
        ViewBag.Upcoming = _portal.GetUpcomingAppointments(5);
        return View(_portal.GetStatistics());
    }

    public IActionResult Statistics() => View(_portal.GetStatistics());

    public IActionResult Uml() => View();
}
