using MedicalPortalApp.Models;
using MedicalPortalApp.Services;
using Microsoft.AspNetCore.Mvc;

namespace MedicalPortalApp.Controllers;

public class PaymentsController : Controller
{
    private readonly MedicalPortal _portal;
    public PaymentsController(MedicalPortal portal) => _portal = portal;

    public IActionResult Index() => View(_portal.GetPayments());

    public IActionResult Create(int? patientId)
    {
        FillLists();
        ViewBag.PatientId = patientId;
        return View();
    }

    [HttpPost]
    public IActionResult Create(int patientId, int? serviceId, decimal? amount)
    {
        try
        {
            var payment = _portal.MakePayment(patientId, serviceId, amount);
            TempData["Ok"] = $"Оплата принята: {payment.Amount.Money()}.";
            return RedirectToAction(nameof(Index));
        }
        catch (ArgumentException ex)
        {
            ViewBag.Error = ex.Message;
            FillLists();
            ViewBag.PatientId = patientId;
            return View();
        }
    }

    [HttpPost]
    public IActionResult Refund(int id)
    {
        try { TempData["Ok"] = _portal.RefundPayment(id); }
        catch (ArgumentException ex) { TempData["Err"] = ex.Message; }
        return RedirectToAction(nameof(Index));
    }

    private void FillLists()
    {
        ViewBag.Patients = _portal.GetPatients();
        ViewBag.Services = _portal.GetServices();
    }
}
