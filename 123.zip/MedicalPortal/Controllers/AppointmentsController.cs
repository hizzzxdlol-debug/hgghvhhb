using MedicalPortalApp.Services;
using Microsoft.AspNetCore.Mvc;

namespace MedicalPortalApp.Controllers;

public class AppointmentsController : Controller
{
    private readonly MedicalPortal _portal;
    public AppointmentsController(MedicalPortal portal) => _portal = portal;

    public IActionResult Index() => View(_portal.GetAppointments());

    public IActionResult Create(int? patientId, int? doctorId)
    {
        FillLists();
        ViewBag.PatientId = patientId;
        ViewBag.DoctorId = doctorId;
        return View();
    }

    [HttpPost]
    public IActionResult Create(int patientId, int doctorId, DateTime appointmentDate, TimeSpan appointmentTime, int? serviceId)
    {
        try
        {
            _portal.BookAppointment(patientId, doctorId, appointmentDate, appointmentTime, serviceId);
            TempData["Ok"] = "Пациент записан на приём.";
            return RedirectToAction(nameof(Index));
        }
        catch (ArgumentException ex)
        {
            // Для занятого времени здесь будет сообщение: «Врач уже занят на указанное время!»
            ViewBag.Error = ex.Message;
            FillLists();
            ViewBag.PatientId = patientId;
            ViewBag.DoctorId = doctorId;
            return View();
        }
    }

    [HttpPost]
    public IActionResult Confirm(int id) => Run(() => _portal.ConfirmAppointment(id));

    [HttpPost]
    public IActionResult Cancel(int id) => Run(() => _portal.CancelAppointment(id));

    [HttpPost]
    public IActionResult Complete(int id) => Run(() => _portal.CompleteAppointment(id));

    private IActionResult Run(Func<string> action)
    {
        try { TempData["Ok"] = action(); }
        catch (ArgumentException ex) { TempData["Err"] = ex.Message; }
        return RedirectToAction(nameof(Index));
    }

    private void FillLists()
    {
        ViewBag.Patients = _portal.GetPatients();
        ViewBag.Doctors = _portal.GetDoctors();
        ViewBag.Services = _portal.GetServices();
    }
}
