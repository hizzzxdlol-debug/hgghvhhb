using MedicalPortalApp.Services;
using Microsoft.AspNetCore.Mvc;

namespace MedicalPortalApp.Controllers;

public class ServicesController : Controller
{
    private readonly MedicalPortal _portal;
    public ServicesController(MedicalPortal portal) => _portal = portal;

    public IActionResult Index() => View(_portal.GetServices());

    public IActionResult Create() => View();

    [HttpPost]
    public IActionResult Create(string? serviceName, string? description, decimal price, int duration)
    {
        try
        {
            _portal.AddService(serviceName, description, price, duration);
            TempData["Ok"] = "Услуга добавлена.";
            return RedirectToAction(nameof(Index));
        }
        catch (ArgumentException ex)
        {
            ViewBag.Error = ex.Message;
            return View();
        }
    }

    [HttpPost]
    public IActionResult UpdatePrice(int id, decimal price)
    {
        try { _portal.UpdateServicePrice(id, price); TempData["Ok"] = "Стоимость услуги изменена."; }
        catch (ArgumentException ex) { TempData["Err"] = ex.Message; }
        return RedirectToAction(nameof(Index));
    }
}
