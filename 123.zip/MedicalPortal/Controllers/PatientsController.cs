using MedicalPortalApp.Models;
using MedicalPortalApp.Services;
using Microsoft.AspNetCore.Mvc;

namespace MedicalPortalApp.Controllers;

public class PatientsController : Controller
{
    private readonly MedicalPortal _portal;
    public PatientsController(MedicalPortal portal) => _portal = portal;

    // Задача 23: поиск по ID, ФИО или телефону
    public IActionResult Index(string? q)
    {
        List<Patient> list;
        if (string.IsNullOrWhiteSpace(q))
        {
            list = _portal.GetPatients();
        }
        else
        {
            list = _portal.SearchPatients(q);
            if (list.Count == 0)
                ViewBag.Message = $"Пациент по запросу «{q}» не найден. Проверьте ID, ФИО или номер телефона.";
        }
        ViewBag.Query = q;
        return View(list);
    }

    public IActionResult Details(int id)
    {
        var patient = _portal.GetPatientDetails(id);
        if (patient == null) return NotFound();
        return View(patient);
    }

    public IActionResult Create() => View();

    [HttpPost]
    public IActionResult Create(string? fullName, DateTime birthDate, string? phoneNumber, string? email, string? address)
    {
        try
        {
            var patient = _portal.AddPatient(fullName, birthDate, phoneNumber, email, address);
            TempData["Ok"] = $"Пациент «{patient.FullName}» добавлен (ID {patient.Id}).";
            return RedirectToAction(nameof(Details), new { id = patient.Id });
        }
        catch (ArgumentException ex)
        {
            ViewBag.Error = ex.Message;
            return View();
        }
    }

    public IActionResult Edit(int id)
    {
        var patient = _portal.GetPatientDetails(id);
        if (patient == null) return NotFound();
        return View(patient);
    }

    [HttpPost]
    public IActionResult Edit(int id, string? fullName, string? phoneNumber, string? email, string? address)
    {
        try
        {
            _portal.UpdatePatient(id, fullName, phoneNumber, email, address);
            TempData["Ok"] = "Профиль пациента обновлён.";
            return RedirectToAction(nameof(Details), new { id });
        }
        catch (ArgumentException ex)
        {
            ViewBag.Error = ex.Message;
            var patient = _portal.GetPatientDetails(id);
            if (patient == null) return NotFound();
            return View(patient);
        }
    }

    [HttpPost]
    public IActionResult Delete(int id)
    {
        try
        {
            _portal.DeletePatient(id);
            TempData["Ok"] = "Пациент удалён вместе с медицинской картой.";
        }
        catch (ArgumentException ex) { TempData["Err"] = ex.Message; }
        return RedirectToAction(nameof(Index));
    }

    [HttpPost]
    public IActionResult AddDiagnosis(int id, string? diagnosis)
    {
        try { _portal.AddDiagnosis(id, diagnosis); TempData["Ok"] = "Диагноз добавлен."; }
        catch (ArgumentException ex) { TempData["Err"] = ex.Message; }
        return RedirectToAction(nameof(Details), new { id });
    }

    [HttpPost]
    public IActionResult UpdateHistory(int id, string? note)
    {
        try { _portal.UpdateHistory(id, note); TempData["Ok"] = "История болезни обновлена."; }
        catch (ArgumentException ex) { TempData["Err"] = ex.Message; }
        return RedirectToAction(nameof(Details), new { id });
    }
}
