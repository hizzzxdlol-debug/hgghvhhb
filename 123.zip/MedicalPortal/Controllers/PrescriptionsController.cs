using MedicalPortalApp.Services;
using Microsoft.AspNetCore.Mvc;

namespace MedicalPortalApp.Controllers;

public class PrescriptionsController : Controller
{
    private readonly MedicalPortal _portal;
    public PrescriptionsController(MedicalPortal portal) => _portal = portal;

    public IActionResult Index() => View(_portal.GetPrescriptions());

    public IActionResult Create(int? patientId)
    {
        FillLists();
        ViewBag.PatientId = patientId;
        return View();
    }

    [HttpPost]
    public IActionResult Create(int patientId, int doctorId, string? medicationName, string? dosage, int duration)
    {
        try
        {
            _portal.CreatePrescription(patientId, doctorId, medicationName, dosage, duration);
            TempData["Ok"] = "Назначение создано.";
            return RedirectToAction(nameof(Index));
        }
        catch (ArgumentException ex)
        {
            ViewBag.Error = ex.Message;
            FillLists();
            ViewBag.PatientId = patientId;
            return View();
        }
    }

    private void FillLists()
    {
        ViewBag.Patients = _portal.GetPatients();
        ViewBag.Doctors = _portal.GetDoctors();
    }
}
