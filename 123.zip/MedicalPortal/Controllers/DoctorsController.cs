using MedicalPortalApp.Services;
using Microsoft.AspNetCore.Mvc;

namespace MedicalPortalApp.Controllers;

public class DoctorsController : Controller
{
    private readonly MedicalPortal _portal;
    public DoctorsController(MedicalPortal portal) => _portal = portal;

    public IActionResult Index() => View(_portal.GetDoctors());

    // Расписание врача + проверка доступности на дату (задача 7)
    public IActionResult Details(int id, DateTime? date)
    {
        var doctor = _portal.GetDoctorDetails(id);
        if (doctor == null) return NotFound();

        var day = (date ?? DateTime.Today).Date;
        ViewBag.Date = day;
        ViewBag.Available = doctor.IsDoctorAvailable(day);
        ViewBag.Slots = doctor.GetFreeSlots(day);
        ViewBag.DaySchedule = _portal.GetDoctorSchedule(id, day)
            .Where(a => a.Status != Models.AppointmentStatus.Cancelled).ToList();
        return View(doctor);
    }

    public IActionResult Create()
    {
        ViewBag.Departments = _portal.GetDepartments();
        return View();
    }

    [HttpPost]
    public IActionResult Create(string? fullName, DateTime birthDate, string? specialization, int experience,
                                int cabinetNumber, decimal salary, int? departmentId)
    {
        try
        {
            var doctor = _portal.AddDoctor(fullName, birthDate, specialization, experience, cabinetNumber, salary, departmentId);
            TempData["Ok"] = $"Врач «{doctor.FullName}» добавлен (ID {doctor.Id}).";
            return RedirectToAction(nameof(Details), new { id = doctor.Id });
        }
        catch (ArgumentException ex)
        {
            ViewBag.Error = ex.Message;
            ViewBag.Departments = _portal.GetDepartments();
            return View();
        }
    }

    [HttpPost]
    public IActionResult UpdateSpecialization(int id, string? specialization)
    {
        try { _portal.UpdateSpecialization(id, specialization); TempData["Ok"] = "Специализация обновлена."; }
        catch (ArgumentException ex) { TempData["Err"] = ex.Message; }
        return RedirectToAction(nameof(Details), new { id });
    }

    [HttpPost]
    public IActionResult Delete(int id)
    {
        try { _portal.DeleteDoctor(id); TempData["Ok"] = "Врач удалён."; }
        catch (ArgumentException ex) { TempData["Err"] = ex.Message; }
        return RedirectToAction(nameof(Index));
    }
}
