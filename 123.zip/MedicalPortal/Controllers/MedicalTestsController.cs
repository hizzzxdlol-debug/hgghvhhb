using MedicalPortalApp.Services;
using Microsoft.AspNetCore.Mvc;

namespace MedicalPortalApp.Controllers;

public class MedicalTestsController : Controller
{
    private readonly MedicalPortal _portal;
    public MedicalTestsController(MedicalPortal portal) => _portal = portal;

    public IActionResult Index() => View(_portal.GetTests());

    public IActionResult Create(int? patientId)
    {
        ViewBag.Patients = _portal.GetPatients();
        ViewBag.PatientId = patientId;
        return View();
    }

    [HttpPost]
    public IActionResult Create(int patientId, string? testName, DateTime? testDate, string? result)
    {
        try
        {
            _portal.AddTest(patientId, testName, testDate ?? DateTime.Today, result);
            TempData["Ok"] = "Анализ добавлен.";
            return RedirectToAction(nameof(Index));
        }
        catch (ArgumentException ex)
        {
            ViewBag.Error = ex.Message;
            ViewBag.Patients = _portal.GetPatients();
            ViewBag.PatientId = patientId;
            return View();
        }
    }

    [HttpPost]
    public IActionResult SetResult(int id, string? result)
    {
        try { _portal.SetTestResult(id, result); TempData["Ok"] = "Результат сохранён."; }
        catch (ArgumentException ex) { TempData["Err"] = ex.Message; }
        return RedirectToAction(nameof(Index));
    }
}
