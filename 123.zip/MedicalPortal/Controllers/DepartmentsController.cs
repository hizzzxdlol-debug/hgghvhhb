using MedicalPortalApp.Services;
using Microsoft.AspNetCore.Mvc;

namespace MedicalPortalApp.Controllers;

public class DepartmentsController : Controller
{
    private readonly MedicalPortal _portal;
    public DepartmentsController(MedicalPortal portal) => _portal = portal;

    public IActionResult Index() => View(_portal.GetDepartments());

    public IActionResult Details(int id)
    {
        var dep = _portal.GetDepartmentDetails(id);
        if (dep == null) return NotFound();
        ViewBag.FreeDoctors = _portal.GetDoctors().Where(d => d.DepartmentId == null).ToList();
        return View(dep);
    }

    public IActionResult Create() => View();

    [HttpPost]
    public IActionResult Create(string? departmentName, int floor, string? phoneNumber)
    {
        try
        {
            var dep = _portal.AddDepartment(departmentName, floor, phoneNumber, null);
            TempData["Ok"] = $"Отделение «{dep.DepartmentName}» создано.";
            return RedirectToAction(nameof(Details), new { id = dep.DepartmentId });
        }
        catch (ArgumentException ex)
        {
            ViewBag.Error = ex.Message;
            return View();
        }
    }

    [HttpPost]
    public IActionResult AddDoctor(int id, int doctorId)
    {
        try { _portal.AddDoctorToDepartment(id, doctorId); TempData["Ok"] = "Врач добавлен в отделение."; }
        catch (ArgumentException ex) { TempData["Err"] = ex.Message; }
        return RedirectToAction(nameof(Details), new { id });
    }

    [HttpPost]
    public IActionResult RemoveDoctor(int id, int doctorId)
    {
        try { _portal.RemoveDoctorFromDepartment(id, doctorId); TempData["Ok"] = "Врач убран из отделения (он остаётся в системе)."; }
        catch (ArgumentException ex) { TempData["Err"] = ex.Message; }
        return RedirectToAction(nameof(Details), new { id });
    }

    [HttpPost]
    public IActionResult SetHead(int id, int doctorId)
    {
        try { _portal.SetHeadDoctor(id, doctorId); TempData["Ok"] = "Заведующий назначен."; }
        catch (ArgumentException ex) { TempData["Err"] = ex.Message; }
        return RedirectToAction(nameof(Details), new { id });
    }

    [HttpPost]
    public IActionResult Delete(int id)
    {
        try { _portal.DeleteDepartment(id); TempData["Ok"] = "Отделение удалено, врачи сохранены."; }
        catch (ArgumentException ex) { TempData["Err"] = ex.Message; }
        return RedirectToAction(nameof(Index));
    }
}
