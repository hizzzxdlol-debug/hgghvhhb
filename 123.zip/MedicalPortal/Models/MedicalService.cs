using System.ComponentModel.DataAnnotations;

namespace MedicalPortalApp.Models;

/// <summary>Задача 5. Медицинская услуга.</summary>
public class MedicalService
{
    private string _serviceName = string.Empty;
    private decimal _price;
    private int _duration = 30;

    [Key]
    public int ServiceId { get; set; }

    public string ServiceName
    {
        get => _serviceName;
        set
        {
            if (string.IsNullOrWhiteSpace(value))
                throw new ArgumentException("Название услуги не может быть пустым.");
            _serviceName = value.Trim();
        }
    }

    public string Description { get; set; } = string.Empty;

    public decimal Price
    {
        get => _price;
        set
        {
            if (value < 0)
                throw new ArgumentException("Стоимость услуги не может быть меньше нуля.");
            _price = value;
        }
    }

    /// <summary>Длительность в минутах.</summary>
    public int Duration
    {
        get => _duration;
        set
        {
            if (value <= 0)
                throw new ArgumentException("Длительность услуги должна быть положительной.");
            _duration = value;
        }
    }

    /// <summary>Итоговая цена за количество процедур с учётом скидки в процентах.</summary>
    public decimal CalculatePrice(int quantity = 1, decimal discountPercent = 0)
    {
        if (quantity <= 0) throw new ArgumentException("Количество должно быть положительным.");
        if (discountPercent < 0 || discountPercent > 100) throw new ArgumentException("Скидка должна быть от 0 до 100%.");
        return Math.Round(Price * quantity * (1 - discountPercent / 100m), 2);
    }

    public void UpdatePrice(decimal newPrice)
    {
        Price = newPrice;
    }

    public void DisplayService()
    {
        Console.WriteLine($"[Услуга #{ServiceId}] {ServiceName} — {Price.Money()}, {Duration} мин. {Description}");
    }
}
