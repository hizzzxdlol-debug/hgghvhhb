namespace MedicalPortalApp.Models;

/// <summary>Задача 21. Оплата медицинских услуг (оплата и возврат).</summary>
public class Payment
{
    private decimal _amount;

    public int PaymentId { get; set; }

    public int PatientId { get; set; }
    public Patient Patient { get; set; } = null!;

    public int? MedicalServiceId { get; set; }
    public MedicalService? MedicalService { get; set; }

    public decimal Amount
    {
        get => _amount;
        set
        {
            if (value <= 0)
                throw new ArgumentException("Сумма оплаты должна быть больше нуля.");
            _amount = value;
        }
    }

    public DateTime PaymentDate { get; set; } = DateTime.Now;
    public PaymentStatus PaymentStatus { get; set; } = PaymentStatus.Pending;

    public (bool Success, string Message) MakePayment()
    {
        if (PaymentStatus == PaymentStatus.Paid)
            return (false, "Платёж уже оплачен.");
        if (PaymentStatus == PaymentStatus.Refunded)
            return (false, "Платёж уже возвращён, повторная оплата невозможна.");
        PaymentStatus = PaymentStatus.Paid;
        PaymentDate = DateTime.Now;
        return (true, $"Оплата {Amount.Money()} принята.");
    }

    public (bool Success, string Message) RefundPayment()
    {
        if (PaymentStatus != PaymentStatus.Paid)
            return (false, "Вернуть можно только оплаченный платёж.");
        PaymentStatus = PaymentStatus.Refunded;
        return (true, $"Возврат {Amount.Money()} выполнен.");
    }

    public void DisplayPayment()
    {
        Console.WriteLine($"[Платёж #{PaymentId}] {PaymentDate:dd.MM.yyyy HH:mm} | {Patient?.FullName} | " +
                          $"{Amount.Money()} | {PaymentStatus.ToRu()}");
    }
}
