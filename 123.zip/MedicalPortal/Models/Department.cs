using System.ComponentModel.DataAnnotations.Schema;

namespace MedicalPortalApp.Models;

/// <summary>Задачи 4 и 13. Отделение. Агрегация: отделение содержит врачей, но врачи существуют независимо.</summary>
public class Department
{
    private string _departmentName = string.Empty;
    private int _floor;
    private string _phoneNumber = string.Empty;

    public int DepartmentId { get; set; }

    public string DepartmentName
    {
        get => _departmentName;
        set
        {
            if (string.IsNullOrWhiteSpace(value))
                throw new ArgumentException("Название отделения не может быть пустым.");
            _departmentName = value.Trim();
        }
    }

    public int Floor
    {
        get => _floor;
        set
        {
            if (value < 0)
                throw new ArgumentException("Этаж не может быть отрицательным.");
            _floor = value;
        }
    }

    public string PhoneNumber
    {
        get => _phoneNumber;
        set
        {
            if (string.IsNullOrWhiteSpace(value))
                throw new ArgumentException("Телефон отделения не может быть пустым.");
            _phoneNumber = value.Trim();
        }
    }

    public int? HeadDoctorId { get; set; }
    [ForeignKey(nameof(HeadDoctorId))]
    public Doctor? HeadDoctor { get; set; }

    [InverseProperty(nameof(Doctor.Department))]
    public List<Doctor> Doctors { get; set; } = new();

    public void AddDoctor(Doctor doctor)
    {
        if (doctor == null) throw new ArgumentException("Врач не указан.");
        if (Doctors.Contains(doctor)) return;
        doctor.Department = this;
        Doctors.Add(doctor);
    }

    public void RemoveDoctor(Doctor doctor)
    {
        if (doctor == null || !Doctors.Remove(doctor)) return;
        doctor.Department = null;
        doctor.DepartmentId = null;
        if (HeadDoctor == doctor || (doctor.Id != 0 && HeadDoctorId == doctor.Id))
        {
            HeadDoctor = null;
            HeadDoctorId = null;
        }
    }

    public void DisplayDoctors()
    {
        Console.WriteLine($"Отделение «{DepartmentName}» (этаж {Floor}), врачей: {Doctors.Count}");
        if (Doctors.Count == 0)
        {
            Console.WriteLine("  В отделении пока нет врачей.");
            return;
        }
        foreach (var d in Doctors)
            Console.WriteLine($"  - {d.FullName} ({d.Specialization}), каб. {d.CabinetNumber}" + (d == HeadDoctor ? "  [заведующий]" : ""));
    }
}
