using System.ComponentModel.DataAnnotations.Schema;

namespace MedicalPortalApp.Models;

/// <summary>Задачи 2, 11, 14, 17, 19. Пациент (наследник Person).</summary>
public class Patient : Person
{
    private string _phoneNumber = string.Empty;
    private string _email = string.Empty;
    private string _address = string.Empty;

    [NotMapped]
    public int PatientId => Id;

    public string PhoneNumber
    {
        get => _phoneNumber;
        set
        {
            if (string.IsNullOrWhiteSpace(value))
                throw new ArgumentException("Номер телефона не может быть пустым.");
            if (value.Count(char.IsDigit) < 5)
                throw new ArgumentException("Номер телефона должен содержать не менее 5 цифр.");
            _phoneNumber = value.Trim();
        }
    }

    public string Email
    {
        get => _email;
        set
        {
            if (string.IsNullOrWhiteSpace(value))
                throw new ArgumentException("Email не может быть пустым.");
            if (!value.Contains('@') || value.Trim().EndsWith('@') || value.Trim().StartsWith('@'))
                throw new ArgumentException("Email указан некорректно.");
            _email = value.Trim();
        }
    }

    public string Address
    {
        get => _address;
        set
        {
            if (string.IsNullOrWhiteSpace(value))
                throw new ArgumentException("Адрес не может быть пустым.");
            _address = value.Trim();
        }
    }

    // Задача 11: ассоциация 1 пациент — 0..* записей на приём
    public List<Appointment> Appointments { get; set; } = new();

    // Задача 14: композиция Patient 1 — 1 MedicalRecord (карта живёт и удаляется вместе с пациентом)
    public MedicalRecord? MedicalRecord { get; set; }

    public List<MedicalTest> Tests { get; set; } = new();
    public List<Prescription> Prescriptions { get; set; } = new();
    public List<Payment> Payments { get; set; } = new();

    public int GetAge() => CalculateAge();

    public void UpdateProfile(string? fullName, string? phoneNumber, string? email, string? address)
    {
        // Если какое-то значение не пройдёт проверку, возвращаем прежний профиль целиком.
        var backup = (FullName, PhoneNumber, Email, Address);
        try
        {
            FullName = fullName ?? string.Empty;
            PhoneNumber = phoneNumber ?? string.Empty;
            Email = email ?? string.Empty;
            Address = address ?? string.Empty;
        }
        catch
        {
            FullName = backup.FullName;
            PhoneNumber = backup.PhoneNumber;
            Email = backup.Email;
            Address = backup.Address;
            throw;
        }
    }

    public override void DisplayInfo()
    {
        Console.WriteLine($"[Пациент #{Id}] {FullName}, {GetAge()} лет, тел.: {PhoneNumber}, email: {Email}, адрес: {Address}");
    }
}
