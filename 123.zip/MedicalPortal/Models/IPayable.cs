namespace MedicalPortalApp.Models;

/// <summary>Задача 18. Интерфейс для объектов, которые могут рассчитывать выплату / сумму к оплате.</summary>
public interface IPayable
{
    decimal CalculatePayment();
}
