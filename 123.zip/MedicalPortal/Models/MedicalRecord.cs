using System.ComponentModel.DataAnnotations;

namespace MedicalPortalApp.Models;

/// <summary>
/// Задачи 9 и 14. Медицинская карта.
/// Композиция с Patient: карта создаётся вместе с пациентом, не существует без него
/// и удаляется каскадно при удалении пациента.
/// </summary>
public class MedicalRecord
{
    [Key]
    public int RecordId { get; set; }

    public int PatientId { get; set; }
    public Patient Patient { get; set; } = null!;

    public string Diagnosis { get; set; } = string.Empty;
    public string MedicalHistory { get; set; } = string.Empty;
    public DateTime CreationDate { get; set; } = DateTime.Now;

    public void AddDiagnosis(string? diagnosis)
    {
        if (string.IsNullOrWhiteSpace(diagnosis))
            throw new ArgumentException("Диагноз не может быть пустым.");
        Diagnosis = string.IsNullOrEmpty(Diagnosis) ? diagnosis.Trim() : Diagnosis + "; " + diagnosis.Trim();
        UpdateHistory($"Установлен диагноз: {diagnosis.Trim()}");
    }

    public void UpdateHistory(string? note)
    {
        if (string.IsNullOrWhiteSpace(note))
            throw new ArgumentException("Запись в истории болезни не может быть пустой.");
        var line = $"[{DateTime.Now:dd.MM.yyyy}] {note.Trim()}";
        MedicalHistory = string.IsNullOrEmpty(MedicalHistory) ? line : MedicalHistory + Environment.NewLine + line;
    }

    public void DisplayRecord()
    {
        Console.WriteLine($"[Карта #{RecordId}] пациент: {Patient?.FullName}, создана {CreationDate:dd.MM.yyyy}");
        Console.WriteLine($"  Диагноз: {(string.IsNullOrEmpty(Diagnosis) ? "не установлен" : Diagnosis)}");
        Console.WriteLine($"  История болезни: {(string.IsNullOrEmpty(MedicalHistory) ? "записей нет" : MedicalHistory)}");
    }
}
