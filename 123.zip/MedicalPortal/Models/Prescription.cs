namespace MedicalPortalApp.Models;

/// <summary>Задача 22. Медицинское назначение (препарат).</summary>
public class Prescription
{
    private string _medicationName = string.Empty;
    private string _dosage = string.Empty;
    private int _duration = 1;

    public int PrescriptionId { get; set; }

    public int PatientId { get; set; }
    public Patient Patient { get; set; } = null!;

    public int DoctorId { get; set; }
    public Doctor Doctor { get; set; } = null!;

    public DateTime PrescriptionDate { get; set; } = DateTime.Today;

    public string MedicationName
    {
        get => _medicationName;
        set
        {
            if (string.IsNullOrWhiteSpace(value))
                throw new ArgumentException("Название препарата не может быть пустым.");
            _medicationName = value.Trim();
        }
    }

    public string Dosage
    {
        get => _dosage;
        set
        {
            if (string.IsNullOrWhiteSpace(value))
                throw new ArgumentException("Дозировка не может быть пустой.");
            _dosage = value.Trim();
        }
    }

    /// <summary>Длительность курса в днях.</summary>
    public int Duration
    {
        get => _duration;
        set
        {
            if (value <= 0)
                throw new ArgumentException("Длительность курса должна быть положительной (в днях).");
            _duration = value;
        }
    }

    public void CreatePrescription()
    {
        if (Patient == null || Doctor == null)
            throw new ArgumentException("Не указан пациент или врач.");
        PrescriptionDate = DateTime.Today;
        if (!Patient.Prescriptions.Contains(this)) Patient.Prescriptions.Add(this);
        if (!Doctor.Prescriptions.Contains(this)) Doctor.Prescriptions.Add(this);
    }

    public void UpdatePrescription(string? medicationName, string? dosage, int duration)
    {
        MedicationName = medicationName ?? string.Empty;
        Dosage = dosage ?? string.Empty;
        Duration = duration;
    }

    public void DisplayPrescription()
    {
        Console.WriteLine($"[Назначение #{PrescriptionId}] {PrescriptionDate:dd.MM.yyyy} | пациент: {Patient?.FullName} | " +
                          $"врач: {Doctor?.FullName} | {MedicationName}, {Dosage}, {Duration} дн.");
    }
}
