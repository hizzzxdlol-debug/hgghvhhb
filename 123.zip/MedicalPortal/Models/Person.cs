namespace MedicalPortalApp.Models;

/// <summary>
/// Задача 16. Абстрактный базовый класс для всех людей в системе.
/// Задача 19. Инкапсуляция: поля закрыты (private), доступ через свойства с проверкой.
/// </summary>
public abstract class Person
{
    private string _fullName = string.Empty;
    private DateTime _birthDate = DateTime.Today;

    public int Id { get; set; }

    public string FullName
    {
        get => _fullName;
        set
        {
            if (string.IsNullOrWhiteSpace(value))
                throw new ArgumentException("ФИО не может быть пустым.");
            _fullName = value.Trim();
        }
    }

    public DateTime BirthDate
    {
        get => _birthDate;
        set
        {
            if (value.Date > DateTime.Today)
                throw new ArgumentException("Дата рождения не может быть в будущем (возраст не может быть отрицательным).");
            if (value.Year < 1900)
                throw new ArgumentException("Дата рождения указана некорректно.");
            _birthDate = value.Date;
        }
    }

    protected int CalculateAge()
    {
        var today = DateTime.Today;
        int age = today.Year - BirthDate.Year;
        if (BirthDate.Date > today.AddYears(-age)) age--;
        return age;
    }

    /// <summary>Абстрактный метод: каждый наследник выводит информацию по-своему.</summary>
    public abstract void DisplayInfo();
}
