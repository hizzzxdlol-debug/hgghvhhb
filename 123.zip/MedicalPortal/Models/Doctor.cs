using System.ComponentModel.DataAnnotations.Schema;

namespace MedicalPortalApp.Models;

/// <summary>Задачи 3, 7, 8, 12, 17, 18. Врач (наследник Person, реализует IPayable).</summary>
public class Doctor : Person, IPayable
{
    // Рабочий день врача и длительность одного приёма (слота)
    public static readonly TimeSpan WorkDayStart = TimeSpan.FromHours(9);
    public static readonly TimeSpan WorkDayEnd = TimeSpan.FromHours(17);
    public static readonly TimeSpan SlotLength = TimeSpan.FromMinutes(30);

    private string _specialization = string.Empty;
    private int _experience;
    private int _cabinetNumber = 1;
    private decimal _salary;

    [NotMapped]
    public int DoctorId => Id;

    public string Specialization
    {
        get => _specialization;
        set
        {
            if (string.IsNullOrWhiteSpace(value))
                throw new ArgumentException("Специализация не может быть пустой.");
            _specialization = value.Trim();
        }
    }

    /// <summary>Стаж в годах.</summary>
    public int Experience
    {
        get => _experience;
        set
        {
            if (value < 0 || value > 70)
                throw new ArgumentException("Стаж должен быть от 0 до 70 лет.");
            _experience = value;
        }
    }

    public int CabinetNumber
    {
        get => _cabinetNumber;
        set
        {
            if (value <= 0)
                throw new ArgumentException("Номер кабинета должен быть положительным.");
            _cabinetNumber = value;
        }
    }

    /// <summary>Базовый оклад.</summary>
    public decimal Salary
    {
        get => _salary;
        set
        {
            if (value < 0)
                throw new ArgumentException("Зарплата не может быть отрицательной.");
            _salary = value;
        }
    }

    // Задача 13: агрегация — врач может существовать без отделения
    public int? DepartmentId { get; set; }
    [ForeignKey(nameof(DepartmentId))]
    public Department? Department { get; set; }

    // Задача 12: 1 врач — 0..* записей на приём
    public List<Appointment> Appointments { get; set; } = new();
    public List<Prescription> Prescriptions { get; set; } = new();

    public void UpdateSpecialization(string? newSpecialization)
    {
        Specialization = newSpecialization ?? string.Empty;
    }

    /// <summary>Оклад + 2% за каждый год стажа (бонус не более 50%).</summary>
    public decimal CalculateSalary()
    {
        decimal bonusPercent = Math.Min(Experience * 2, 50) / 100m;
        return Math.Round(Salary * (1 + bonusPercent), 2);
    }

    public decimal CalculatePayment() => CalculateSalary();

    // ---------- Расписание (задачи 7 и 8) ----------

    /// <summary>Попадает ли время начала в рабочий день врача.</summary>
    public bool IsWorkingTime(DateTime start)
    {
        var t = start.TimeOfDay;
        return t >= WorkDayStart && t + SlotLength <= WorkDayEnd;
    }

    /// <summary>Свободно ли время: нет активной записи, пересекающейся с этим слотом.</summary>
    public bool IsSlotFree(DateTime start)
    {
        foreach (var a in Appointments)
        {
            if (a.Status == AppointmentStatus.Cancelled) continue;
            if ((a.StartAt - start).Duration() < SlotLength) return false;
        }
        return true;
    }

    /// <summary>Свободные слоты врача на указанный день (прошедшее время не показывается).</summary>
    public List<TimeSpan> GetFreeSlots(DateTime date)
    {
        var result = new List<TimeSpan>();
        for (var t = WorkDayStart; t + SlotLength <= WorkDayEnd; t += SlotLength)
        {
            var start = date.Date + t;
            if (start <= DateTime.Now) continue;
            if (IsSlotFree(start)) result.Add(t);
        }
        return result;
    }

    /// <summary>
    /// Задача 7. Если передана только дата — есть ли у врача хотя бы один свободный слот в этот день.
    /// Если передана дата со временем — свободно ли именно это время.
    /// </summary>
    public bool IsDoctorAvailable(DateTime date)
    {
        if (date.TimeOfDay == TimeSpan.Zero)
            return GetFreeSlots(date).Count > 0;

        return IsWorkingTime(date) && date > DateTime.Now && IsSlotFree(date);
    }

    public override void DisplayInfo()
    {
        Console.WriteLine($"[Врач #{Id}] {FullName}, {Specialization}, стаж {Experience} лет, кабинет {CabinetNumber}, " +
                          $"оклад {Salary.Money()}, к выплате {CalculateSalary().Money()}");
    }
}
