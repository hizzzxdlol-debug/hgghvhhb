namespace MedicalPortalApp.Models;

/// <summary>Задача 20. Статус записи на приём.</summary>
public enum AppointmentStatus
{
    Scheduled,
    Confirmed,
    Completed,
    Cancelled
}

public enum PaymentStatus
{
    Pending,
    Paid,
    Refunded
}

public static class DisplayExtensions
{
    public static string ToRu(this AppointmentStatus s) => s switch
    {
        AppointmentStatus.Scheduled => "Запланирована",
        AppointmentStatus.Confirmed => "Подтверждена",
        AppointmentStatus.Completed => "Завершена",
        AppointmentStatus.Cancelled => "Отменена",
        _ => s.ToString()
    };

    public static string ToRu(this PaymentStatus s) => s switch
    {
        PaymentStatus.Pending => "Ожидает оплаты",
        PaymentStatus.Paid => "Оплачено",
        PaymentStatus.Refunded => "Возвращено",
        _ => s.ToString()
    };

    public static string ToHm(this TimeSpan t) => t.ToString(@"hh\:mm");

    public static string Money(this decimal value) =>
        value.ToString("N0", System.Globalization.CultureInfo.InvariantCulture).Replace(',', ' ') + " ₸";
}
