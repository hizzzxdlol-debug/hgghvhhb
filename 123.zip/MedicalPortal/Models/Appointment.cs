using System.ComponentModel.DataAnnotations.Schema;

namespace MedicalPortalApp.Models;

/// <summary>Задачи 6, 7, 8, 11, 12, 20. Запись на приём.</summary>
public class Appointment
{
    private DateTime _appointmentDate = DateTime.Today;
    private TimeSpan _appointmentTime = TimeSpan.FromHours(9);

    public int AppointmentId { get; set; }

    public int PatientId { get; set; }
    public Patient Patient { get; set; } = null!;

    public int DoctorId { get; set; }
    public Doctor Doctor { get; set; } = null!;

    public int? MedicalServiceId { get; set; }
    [ForeignKey(nameof(MedicalServiceId))]
    public MedicalService? MedicalService { get; set; }

    public DateTime AppointmentDate
    {
        get => _appointmentDate;
        set => _appointmentDate = value.Date;
    }

    public TimeSpan AppointmentTime
    {
        get => _appointmentTime;
        set
        {
            if (value < TimeSpan.Zero || value >= TimeSpan.FromHours(24))
                throw new ArgumentException("Время приёма указано некорректно.");
            _appointmentTime = value;
        }
    }

    public AppointmentStatus Status { get; set; } = AppointmentStatus.Scheduled;

    [NotMapped]
    public DateTime StartAt => AppointmentDate.Date + AppointmentTime;

    [NotMapped]
    public string DateText => AppointmentDate.ToString("dd.MM.yyyy");

    [NotMapped]
    public string TimeText => AppointmentTime.ToHm();

    /// <summary>
    /// Задачи 6 и 8. Создаёт запись, если врач свободен.
    /// Если время занято — возвращает сообщение «Врач уже занят на указанное время!».
    /// </summary>
    public (bool Success, string Message) CreateAppointment()
    {
        if (Patient == null || Doctor == null)
            return (false, "Не указан пациент или врач.");

        if (!Doctor.IsWorkingTime(StartAt))
            return (false, $"Врач принимает с {Doctor.WorkDayStart.ToHm()} до {Doctor.WorkDayEnd.ToHm()}.");

        if (StartAt <= DateTime.Now)
            return (false, "Нельзя записаться на прошедшее время.");

        if (!Doctor.IsSlotFree(StartAt))
            return (false, "Врач уже занят на указанное время!");

        Status = AppointmentStatus.Scheduled;
        if (!Doctor.Appointments.Contains(this)) Doctor.Appointments.Add(this);
        if (!Patient.Appointments.Contains(this)) Patient.Appointments.Add(this);
        return (true, "Запись на приём создана.");
    }

    public (bool Success, string Message) ConfirmAppointment()
    {
        if (Status != AppointmentStatus.Scheduled)
            return (false, "Подтвердить можно только запланированную запись.");
        Status = AppointmentStatus.Confirmed;
        return (true, "Запись подтверждена.");
    }

    public (bool Success, string Message) CancelAppointment()
    {
        if (Status == AppointmentStatus.Completed)
            return (false, "Завершённый приём отменить нельзя.");
        if (Status == AppointmentStatus.Cancelled)
            return (false, "Запись уже отменена.");
        Status = AppointmentStatus.Cancelled;
        return (true, "Запись отменена.");
    }

    public (bool Success, string Message) CompleteAppointment()
    {
        if (Status != AppointmentStatus.Confirmed && Status != AppointmentStatus.Scheduled)
            return (false, "Завершить можно только активную запись.");
        Status = AppointmentStatus.Completed;
        return (true, "Приём отмечен как завершённый.");
    }

    public void DisplayAppointment()
    {
        Console.WriteLine($"[Запись #{AppointmentId}] {DateText} {TimeText} | пациент: {Patient?.FullName} | " +
                          $"врач: {Doctor?.FullName} | статус: {Status.ToRu()}");
    }
}
