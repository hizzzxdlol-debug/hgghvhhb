using System.ComponentModel.DataAnnotations;

namespace MedicalPortalApp.Models;

/// <summary>Задача 10. Медицинский анализ / исследование.</summary>
public class MedicalTest
{
    private string _testName = string.Empty;

    [Key]
    public int TestId { get; set; }

    public string TestName
    {
        get => _testName;
        set
        {
            if (string.IsNullOrWhiteSpace(value))
                throw new ArgumentException("Название анализа не может быть пустым.");
            _testName = value.Trim();
        }
    }

    public DateTime TestDate { get; set; } = DateTime.Today;
    public string Result { get; set; } = string.Empty;

    public int PatientId { get; set; }
    public Patient Patient { get; set; } = null!;

    public void AddResult(string? result)
    {
        if (string.IsNullOrWhiteSpace(result))
            throw new ArgumentException("Результат не может быть пустым.");
        if (!string.IsNullOrEmpty(Result))
            throw new ArgumentException("Результат уже внесён. Для изменения используйте UpdateResult.");
        Result = result.Trim();
    }

    public void UpdateResult(string? result)
    {
        if (string.IsNullOrWhiteSpace(result))
            throw new ArgumentException("Результат не может быть пустым.");
        Result = result.Trim();
    }

    public void DisplayResult()
    {
        Console.WriteLine($"[Анализ #{TestId}] {TestName} от {TestDate:dd.MM.yyyy}, пациент: {Patient?.FullName}, " +
                          $"результат: {(string.IsNullOrEmpty(Result) ? "ожидается" : Result)}");
    }
}
