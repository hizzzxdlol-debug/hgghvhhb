# Медицинский портал (ASP.NET Core MVC + SQLite)

## Быстрый запуск
1. Установите .NET 8 SDK: https://dotnet.microsoft.com/download/dotnet/8.0
2. В папке проекта (где лежит `MedicalPortal.csproj`) выполните:

       dotnet run

3. Откройте в браузере http://localhost:5080

## Консольное меню (задача 25)

       dotnet run -- console

База данных — файл `medicalportal.db` (создаётся и заполняется тестовыми данными при первом запуске).
Чтобы сбросить данные: остановите программу и удалите `medicalportal.db`.

Подробная инструкция и отчёт — в файле «Инструкция_запуск_и_отчёт.docx». UML — `docs/UML.png`.
