using System.Globalization;
using System.Text;
using MedicalPortalApp.Models;

namespace MedicalPortalApp.Services;

/// <summary>
/// Задача 25. Главное консольное меню медицинского портала.
/// Запуск:  dotnet run -- console
/// </summary>
public class ConsoleMenu
{
    private readonly MedicalPortal _portal;

    public ConsoleMenu(MedicalPortal portal)
    {
        _portal = portal;
    }

    public void Run()
    {
        Console.OutputEncoding = Encoding.UTF8;
        Console.InputEncoding = Encoding.UTF8;

        while (true)
        {
            Console.WriteLine();
            Console.WriteLine("========== MEDICAL PORTAL ==========");
            Console.WriteLine();
            Console.WriteLine("1. Добавить пациента");
            Console.WriteLine("2. Добавить врача");
            Console.WriteLine("3. Показать всех пациентов");
            Console.WriteLine("4. Показать всех врачей");
            Console.WriteLine("5. Записать пациента на приём");
            Console.WriteLine("6. Отменить запись");
            Console.WriteLine("7. Показать расписание врача");
            Console.WriteLine("8. Добавить медицинский анализ");
            Console.WriteLine("9. Создать медицинское назначение");
            Console.WriteLine("10. Оплатить услугу");
            Console.WriteLine("11. Поиск пациента");
            Console.WriteLine("12. Статистика портала");
            Console.WriteLine("0. Выход");
            Console.WriteLine();

            string choice = Ask("Выберите действие: ");
            if (choice == "0")
            {
                Console.WriteLine("До свидания!");
                return;
            }

            try
            {
                switch (choice)
                {
                    case "1": AddPatient(); break;
                    case "2": AddDoctor(); break;
                    case "3": ShowPatients(); break;
                    case "4": ShowDoctors(); break;
                    case "5": BookAppointment(); break;
                    case "6": CancelAppointment(); break;
                    case "7": ShowSchedule(); break;
                    case "8": AddTest(); break;
                    case "9": CreatePrescription(); break;
                    case "10": Pay(); break;
                    case "11": Search(); break;
                    case "12": ShowStatistics(); break;
                    default: Console.WriteLine("Неизвестный пункт меню. Введите число от 0 до 12."); break;
                }
            }
            catch (ArgumentException ex)
            {
                Console.WriteLine("Ошибка: " + ex.Message);
            }
        }
    }

    // ---------- Действия меню ----------

    private void AddPatient()
    {
        var name = Ask("ФИО: ");
        var birth = AskDate("Дата рождения");
        var phone = Ask("Телефон: ");
        var email = Ask("Email: ");
        var address = Ask("Адрес: ");
        var p = _portal.AddPatient(name, birth, phone, email, address);
        Console.WriteLine($"Пациент добавлен. ID = {p.Id}");
    }

    private void AddDoctor()
    {
        var name = Ask("ФИО врача: ");
        var birth = AskDate("Дата рождения");
        var spec = Ask("Специализация: ");
        int exp = AskInt("Стаж (лет): ");
        int cab = AskInt("Номер кабинета: ");
        decimal salary = AskDecimal("Оклад (₸): ");
        var d = _portal.AddDoctor(name, birth, spec, exp, cab, salary);
        Console.WriteLine($"Врач добавлен. ID = {d.Id}");
    }

    private void ShowPatients()
    {
        var list = _portal.GetPatients();
        if (list.Count == 0) { Console.WriteLine("Пациентов пока нет."); return; }
        foreach (var p in list) p.DisplayInfo();
    }

    private void ShowDoctors()
    {
        var list = _portal.GetDoctors();
        if (list.Count == 0) { Console.WriteLine("Врачей пока нет."); return; }
        foreach (var d in list) d.DisplayInfo();
    }

    private void BookAppointment()
    {
        ShowPatients();
        int patientId = AskInt("ID пациента: ");
        ShowDoctors();
        int doctorId = AskInt("ID врача: ");
        var date = AskDate("Дата приёма");
        var time = AskTime("Время приёма");

        var a = _portal.BookAppointment(patientId, doctorId, date, time, null);
        Console.WriteLine("Запись создана:");
        a.DisplayAppointment();
    }

    private void CancelAppointment()
    {
        var active = _portal.GetAppointments()
            .Where(a => a.Status == AppointmentStatus.Scheduled || a.Status == AppointmentStatus.Confirmed).ToList();
        if (active.Count == 0) { Console.WriteLine("Активных записей нет."); return; }
        foreach (var a in active) a.DisplayAppointment();
        int id = AskInt("ID записи для отмены: ");
        Console.WriteLine(_portal.CancelAppointment(id));
    }

    private void ShowSchedule()
    {
        ShowDoctors();
        int doctorId = AskInt("ID врача: ");
        var doctor = _portal.GetDoctorDetails(doctorId) ?? throw new ArgumentException("Врач не найден.");

        string dateText = Ask("Дата (дд.мм.гггг) или Enter — показать всё расписание: ");
        DateTime? date = null;
        if (dateText.Length > 0)
        {
            if (!DateTime.TryParseExact(dateText, "dd.MM.yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out var d))
                throw new ArgumentException("Дата должна быть в формате дд.мм.гггг.");
            date = d;
        }

        var schedule = _portal.GetDoctorSchedule(doctorId, date)
            .Where(a => a.Status != AppointmentStatus.Cancelled).ToList();

        Console.WriteLine($"Расписание: {doctor.FullName} ({doctor.Specialization}), кабинет {doctor.CabinetNumber}");
        if (schedule.Count == 0) Console.WriteLine("  Записей нет.");
        foreach (var a in schedule) a.DisplayAppointment();

        if (date.HasValue)
        {
            var free = doctor.GetFreeSlots(date.Value);
            Console.WriteLine(doctor.IsDoctorAvailable(date.Value)
                ? "Свободное время: " + string.Join(", ", free.Select(t => t.ToHm()))
                : "На эту дату свободного времени нет.");
        }
    }

    private void AddTest()
    {
        ShowPatients();
        int patientId = AskInt("ID пациента: ");
        var name = Ask("Название анализа: ");
        string dateText = Ask("Дата (дд.мм.гггг) или Enter — сегодня: ");
        DateTime date = DateTime.Today;
        if (dateText.Length > 0 &&
            !DateTime.TryParseExact(dateText, "dd.MM.yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out date))
            throw new ArgumentException("Дата должна быть в формате дд.мм.гггг.");
        var result = Ask("Результат (Enter — пока нет): ");

        var test = _portal.AddTest(patientId, name, date, result);
        Console.WriteLine("Анализ добавлен:");
        test.DisplayResult();
    }

    private void CreatePrescription()
    {
        ShowPatients();
        int patientId = AskInt("ID пациента: ");
        ShowDoctors();
        int doctorId = AskInt("ID врача: ");
        var med = Ask("Препарат: ");
        var dosage = Ask("Дозировка: ");
        int days = AskInt("Длительность курса (дней): ");

        var p = _portal.CreatePrescription(patientId, doctorId, med, dosage, days);
        Console.WriteLine("Назначение создано:");
        p.DisplayPrescription();
    }

    private void Pay()
    {
        ShowPatients();
        int patientId = AskInt("ID пациента: ");
        foreach (var s in _portal.GetServices()) s.DisplayService();
        int serviceId = AskInt("ID услуги (0 — ввести сумму вручную): ");

        decimal? amount = null;
        if (serviceId == 0) amount = AskDecimal("Сумма (₸): ");

        var payment = _portal.MakePayment(patientId, serviceId == 0 ? null : serviceId, amount);
        payment.DisplayPayment();
    }

    private void Search()
    {
        string q = Ask("Введите ID, ФИО или телефон: ");
        var found = _portal.SearchPatients(q);
        if (found.Count == 0)
        {
            Console.WriteLine($"Пациент по запросу «{q}» не найден. Проверьте ID, ФИО или номер телефона.");
            return;
        }
        Console.WriteLine($"Найдено: {found.Count}");
        foreach (var p in found) p.DisplayInfo();
    }

    private void ShowStatistics()
    {
        var s = _portal.GetStatistics();
        Console.WriteLine("---------- Статистика портала ----------");
        Console.WriteLine($"Пациентов:                {s.PatientCount}");
        Console.WriteLine($"Врачей:                   {s.DoctorCount}");
        Console.WriteLine($"Записей на приём:         {s.AppointmentCount}");
        Console.WriteLine($"Завершённых приёмов:      {s.CompletedAppointments}");
        Console.WriteLine($"Общая сумма оплат:        {s.TotalPaid.Money()}");
    }

    // ---------- Ввод данных ----------

    private static string Ask(string prompt)
    {
        Console.Write(prompt);
        return Console.ReadLine()?.Trim() ?? string.Empty;
    }

    private static int AskInt(string prompt)
    {
        while (true)
        {
            if (int.TryParse(Ask(prompt), out int value)) return value;
            Console.WriteLine("Введите целое число.");
        }
    }

    private static decimal AskDecimal(string prompt)
    {
        while (true)
        {
            string text = Ask(prompt).Replace(',', '.');
            if (decimal.TryParse(text, NumberStyles.Number, CultureInfo.InvariantCulture, out decimal value)) return value;
            Console.WriteLine("Введите число.");
        }
    }

    private static DateTime AskDate(string prompt)
    {
        while (true)
        {
            string text = Ask($"{prompt} (дд.мм.гггг): ");
            if (DateTime.TryParseExact(text, "dd.MM.yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out var date))
                return date;
            Console.WriteLine("Неверный формат. Пример: 25.11.2026");
        }
    }

    private static TimeSpan AskTime(string prompt)
    {
        while (true)
        {
            string text = Ask($"{prompt} (чч:мм): ");
            if (TimeSpan.TryParseExact(text, @"h\:mm", CultureInfo.InvariantCulture, out var time) ||
                TimeSpan.TryParseExact(text, @"hh\:mm", CultureInfo.InvariantCulture, out time))
                return time;
            Console.WriteLine("Неверный формат. Пример: 10:30");
        }
    }
}
