using MedicalPortalApp.Data;
using MedicalPortalApp.Models;
using Microsoft.EntityFrameworkCore;

namespace MedicalPortalApp.Services;

/// <summary>Задача 24. Сводная статистика портала.</summary>
public class PortalStatistics
{
    public int PatientCount { get; set; }
    public int DoctorCount { get; set; }
    public int AppointmentCount { get; set; }
    public int CompletedAppointments { get; set; }
    public int ActiveAppointments { get; set; }
    public int CancelledAppointments { get; set; }
    public decimal TotalPaid { get; set; }
    public decimal TotalRefunded { get; set; }
}

/// <summary>
/// Главный управляющий класс портала: хранит операции над коллекциями данных.
/// Им пользуются и веб-контроллеры, и консольное меню (задача 25).
/// Ошибки ввода сообщаются через ArgumentException с понятным текстом.
/// </summary>
public class MedicalPortal
{
    private readonly PortalDb _db;

    public MedicalPortal(PortalDb db)
    {
        _db = db;
    }

    // ===================== Пациенты =====================

    public Patient AddPatient(string? fullName, DateTime birthDate, string? phone, string? email, string? address)
    {
        var patient = new Patient
        {
            FullName = fullName ?? string.Empty,
            BirthDate = birthDate,
            PhoneNumber = phone ?? string.Empty,
            Email = email ?? string.Empty,
            Address = address ?? string.Empty
        };
        // Композиция: медицинская карта создаётся вместе с пациентом
        patient.MedicalRecord = new MedicalRecord { Patient = patient, CreationDate = DateTime.Now };

        _db.Patients.Add(patient);
        _db.SaveChanges();
        return patient;
    }

    public List<Patient> GetPatients()
        => _db.Patients.ToList().OrderBy(p => p.FullName).ToList();

    public Patient? GetPatientDetails(int id)
        => _db.Patients
            .Include(p => p.MedicalRecord)
            .Include(p => p.Appointments).ThenInclude(a => a.Doctor)
            .Include(p => p.Tests)
            .Include(p => p.Prescriptions).ThenInclude(x => x.Doctor)
            .Include(p => p.Payments).ThenInclude(x => x.MedicalService)
            .FirstOrDefault(p => p.Id == id);

    public Patient UpdatePatient(int id, string? fullName, string? phone, string? email, string? address)
    {
        var patient = _db.Patients.FirstOrDefault(p => p.Id == id)
                      ?? throw new ArgumentException("Пациент не найден.");
        patient.UpdateProfile(fullName, phone, email, address);
        _db.SaveChanges();
        return patient;
    }

    public void DeletePatient(int id)
    {
        var patient = _db.Patients.FirstOrDefault(p => p.Id == id)
                      ?? throw new ArgumentException("Пациент не найден.");
        _db.Patients.Remove(patient); // карта, записи, анализы и т.д. удаляются каскадно
        _db.SaveChanges();
    }

    /// <summary>Задача 23. Поиск по идентификатору, ФИО или номеру телефона.</summary>
    public List<Patient> SearchPatients(string? query)
    {
        query = (query ?? string.Empty).Trim();
        if (query.Length == 0) return new List<Patient>();

        var all = _db.Patients.ToList();

        if (int.TryParse(query, out int id))
        {
            var byId = all.Where(p => p.Id == id).ToList();
            if (byId.Count > 0) return byId;
        }

        string digits = new string(query.Where(char.IsDigit).ToArray());
        return all.Where(p =>
                p.FullName.Contains(query, StringComparison.OrdinalIgnoreCase) ||
                (digits.Length >= 3 && new string(p.PhoneNumber.Where(char.IsDigit).ToArray()).Contains(digits)))
            .OrderBy(p => p.FullName)
            .ToList();
    }

    public void AddDiagnosis(int patientId, string? diagnosis)
    {
        var record = _db.MedicalRecords.FirstOrDefault(r => r.PatientId == patientId)
                     ?? throw new ArgumentException("Медицинская карта пациента не найдена.");
        record.AddDiagnosis(diagnosis);
        _db.SaveChanges();
    }

    public void UpdateHistory(int patientId, string? note)
    {
        var record = _db.MedicalRecords.FirstOrDefault(r => r.PatientId == patientId)
                     ?? throw new ArgumentException("Медицинская карта пациента не найдена.");
        record.UpdateHistory(note);
        _db.SaveChanges();
    }

    // ===================== Врачи =====================

    public Doctor AddDoctor(string? fullName, DateTime birthDate, string? specialization, int experience,
                            int cabinetNumber, decimal salary, int? departmentId = null)
    {
        var doctor = new Doctor
        {
            FullName = fullName ?? string.Empty,
            BirthDate = birthDate,
            Specialization = specialization ?? string.Empty,
            Experience = experience,
            CabinetNumber = cabinetNumber,
            Salary = salary
        };

        if (departmentId.HasValue)
        {
            var dep = _db.Departments.FirstOrDefault(d => d.DepartmentId == departmentId.Value)
                      ?? throw new ArgumentException("Отделение не найдено.");
            doctor.Department = dep;
        }

        _db.Doctors.Add(doctor);
        _db.SaveChanges();
        return doctor;
    }

    public List<Doctor> GetDoctors()
        => _db.Doctors.Include(d => d.Department).ToList().OrderBy(d => d.FullName).ToList();

    public Doctor? GetDoctorDetails(int id)
        => _db.Doctors
            .Include(d => d.Department)
            .Include(d => d.Appointments).ThenInclude(a => a.Patient)
            .FirstOrDefault(d => d.Id == id);

    public void UpdateSpecialization(int doctorId, string? specialization)
    {
        var doctor = _db.Doctors.FirstOrDefault(d => d.Id == doctorId)
                     ?? throw new ArgumentException("Врач не найден.");
        doctor.UpdateSpecialization(specialization);
        _db.SaveChanges();
    }

    public void DeleteDoctor(int id)
    {
        var doctor = _db.Doctors.FirstOrDefault(d => d.Id == id)
                     ?? throw new ArgumentException("Врач не найден.");
        // Если врач заведует отделением — снимаем с должности (врач — независимый объект, агрегация)
        foreach (var dep in _db.Departments.Where(d => d.HeadDoctorId == id).ToList())
            dep.HeadDoctorId = null;
        _db.SaveChanges();
        _db.Doctors.Remove(doctor);
        _db.SaveChanges();
    }

    /// <summary>Расписание врача: все активные записи (по дате — если дата указана).</summary>
    public List<Appointment> GetDoctorSchedule(int doctorId, DateTime? date = null)
    {
        var list = _db.Appointments
            .Include(a => a.Patient)
            .Include(a => a.Doctor)
            .Where(a => a.DoctorId == doctorId)
            .ToList();

        if (date.HasValue) list = list.Where(a => a.AppointmentDate == date.Value.Date).ToList();
        return list.OrderBy(a => a.AppointmentDate).ThenBy(a => a.AppointmentTime).ToList();
    }

    // ===================== Отделения =====================

    public Department AddDepartment(string? name, int floor, string? phone, int? headDoctorId)
    {
        var dep = new Department
        {
            DepartmentName = name ?? string.Empty,
            Floor = floor,
            PhoneNumber = phone ?? string.Empty
        };
        _db.Departments.Add(dep);
        _db.SaveChanges();

        if (headDoctorId.HasValue)
        {
            var head = _db.Doctors.FirstOrDefault(d => d.Id == headDoctorId.Value)
                       ?? throw new ArgumentException("Заведующий не найден.");
            dep.AddDoctor(head);
            dep.HeadDoctor = head;
            _db.SaveChanges();
        }
        return dep;
    }

    public List<Department> GetDepartments()
        => _db.Departments.Include(d => d.Doctors).Include(d => d.HeadDoctor).ToList()
            .OrderBy(d => d.DepartmentName).ToList();

    public Department? GetDepartmentDetails(int id)
        => _db.Departments.Include(d => d.Doctors).Include(d => d.HeadDoctor)
            .FirstOrDefault(d => d.DepartmentId == id);

    public void AddDoctorToDepartment(int departmentId, int doctorId)
    {
        var dep = GetDepartmentDetails(departmentId) ?? throw new ArgumentException("Отделение не найдено.");
        var doctor = _db.Doctors.FirstOrDefault(d => d.Id == doctorId) ?? throw new ArgumentException("Врач не найден.");
        dep.AddDoctor(doctor);
        _db.SaveChanges();
    }

    public void RemoveDoctorFromDepartment(int departmentId, int doctorId)
    {
        var dep = GetDepartmentDetails(departmentId) ?? throw new ArgumentException("Отделение не найдено.");
        var doctor = dep.Doctors.FirstOrDefault(d => d.Id == doctorId)
                     ?? throw new ArgumentException("Этот врач не работает в данном отделении.");
        dep.RemoveDoctor(doctor);
        _db.SaveChanges();
    }

    public void SetHeadDoctor(int departmentId, int doctorId)
    {
        var dep = GetDepartmentDetails(departmentId) ?? throw new ArgumentException("Отделение не найдено.");
        var doctor = dep.Doctors.FirstOrDefault(d => d.Id == doctorId)
                     ?? throw new ArgumentException("Заведующим может быть только врач этого отделения.");
        dep.HeadDoctor = doctor;
        _db.SaveChanges();
    }

    public void DeleteDepartment(int id)
    {
        var dep = GetDepartmentDetails(id) ?? throw new ArgumentException("Отделение не найдено.");
        foreach (var d in dep.Doctors.ToList()) dep.RemoveDoctor(d); // врачи остаются в системе
        dep.HeadDoctorId = null;
        _db.SaveChanges();
        _db.Departments.Remove(dep);
        _db.SaveChanges();
    }

    // ===================== Услуги =====================

    public MedicalService AddService(string? name, string? description, decimal price, int duration)
    {
        var service = new MedicalService
        {
            ServiceName = name ?? string.Empty,
            Description = description ?? string.Empty,
            Price = price,
            Duration = duration
        };
        _db.Services.Add(service);
        _db.SaveChanges();
        return service;
    }

    public List<MedicalService> GetServices()
        => _db.Services.ToList().OrderBy(s => s.ServiceName).ToList();

    public void UpdateServicePrice(int serviceId, decimal newPrice)
    {
        var service = _db.Services.FirstOrDefault(s => s.ServiceId == serviceId)
                      ?? throw new ArgumentException("Услуга не найдена.");
        service.UpdatePrice(newPrice);
        _db.SaveChanges();
    }

    // ===================== Записи на приём =====================

    public Appointment BookAppointment(int patientId, int doctorId, DateTime date, TimeSpan time, int? serviceId)
    {
        var patient = _db.Patients.FirstOrDefault(p => p.Id == patientId)
                      ?? throw new ArgumentException("Пациент не найден.");
        var doctor = _db.Doctors.Include(d => d.Appointments).FirstOrDefault(d => d.Id == doctorId)
                     ?? throw new ArgumentException("Врач не найден.");

        if (serviceId.HasValue && !_db.Services.Any(s => s.ServiceId == serviceId.Value))
            throw new ArgumentException("Услуга не найдена.");

        var appointment = new Appointment
        {
            Patient = patient,
            Doctor = doctor,
            AppointmentDate = date,
            AppointmentTime = time,
            MedicalServiceId = serviceId
        };

        var (success, message) = appointment.CreateAppointment();
        if (!success) throw new ArgumentException(message); // например: «Врач уже занят на указанное время!»

        _db.Appointments.Add(appointment);
        _db.SaveChanges();
        return appointment;
    }

    public List<Appointment> GetAppointments()
    {
        var list = _db.Appointments.Include(a => a.Patient).Include(a => a.Doctor).Include(a => a.MedicalService).ToList();
        return list.OrderByDescending(a => a.AppointmentDate).ThenBy(a => a.AppointmentTime).ToList();
    }

    public List<Appointment> GetUpcomingAppointments(int count = 5)
    {
        return GetAppointments()
            .Where(a => a.StartAt >= DateTime.Now &&
                        (a.Status == AppointmentStatus.Scheduled || a.Status == AppointmentStatus.Confirmed))
            .OrderBy(a => a.StartAt)
            .Take(count)
            .ToList();
    }

    private Appointment FindAppointment(int id)
        => _db.Appointments.Include(a => a.Patient).Include(a => a.Doctor).FirstOrDefault(a => a.AppointmentId == id)
           ?? throw new ArgumentException("Запись на приём не найдена.");

    public string ConfirmAppointment(int id) => Apply(id, a => a.ConfirmAppointment());
    public string CancelAppointment(int id) => Apply(id, a => a.CancelAppointment());
    public string CompleteAppointment(int id) => Apply(id, a => a.CompleteAppointment());

    private string Apply(int id, Func<Appointment, (bool Success, string Message)> action)
    {
        var appointment = FindAppointment(id);
        var (success, message) = action(appointment);
        if (!success) throw new ArgumentException(message);
        _db.SaveChanges();
        return message;
    }

    // ===================== Анализы =====================

    public MedicalTest AddTest(int patientId, string? testName, DateTime testDate, string? result)
    {
        var patient = _db.Patients.FirstOrDefault(p => p.Id == patientId)
                      ?? throw new ArgumentException("Пациент не найден.");
        var test = new MedicalTest { Patient = patient, TestName = testName ?? string.Empty, TestDate = testDate };
        if (!string.IsNullOrWhiteSpace(result)) test.AddResult(result);
        _db.MedicalTests.Add(test);
        _db.SaveChanges();
        return test;
    }

    public List<MedicalTest> GetTests()
        => _db.MedicalTests.Include(t => t.Patient).ToList().OrderByDescending(t => t.TestDate).ToList();

    public void SetTestResult(int testId, string? result)
    {
        var test = _db.MedicalTests.FirstOrDefault(t => t.TestId == testId)
                   ?? throw new ArgumentException("Анализ не найден.");
        if (string.IsNullOrEmpty(test.Result)) test.AddResult(result);
        else test.UpdateResult(result);
        _db.SaveChanges();
    }

    // ===================== Назначения =====================

    public Prescription CreatePrescription(int patientId, int doctorId, string? medication, string? dosage, int durationDays)
    {
        var patient = _db.Patients.FirstOrDefault(p => p.Id == patientId)
                      ?? throw new ArgumentException("Пациент не найден.");
        var doctor = _db.Doctors.FirstOrDefault(d => d.Id == doctorId)
                     ?? throw new ArgumentException("Врач не найден.");

        var prescription = new Prescription
        {
            Patient = patient,
            Doctor = doctor,
            MedicationName = medication ?? string.Empty,
            Dosage = dosage ?? string.Empty,
            Duration = durationDays
        };
        prescription.CreatePrescription();
        _db.Prescriptions.Add(prescription);
        _db.SaveChanges();
        return prescription;
    }

    public List<Prescription> GetPrescriptions()
        => _db.Prescriptions.Include(p => p.Patient).Include(p => p.Doctor).ToList()
            .OrderByDescending(p => p.PrescriptionDate).ToList();

    // ===================== Оплаты =====================

    /// <summary>Оплата услуги. Если сумма не указана, берётся цена выбранной услуги.</summary>
    public Payment MakePayment(int patientId, int? serviceId, decimal? amount)
    {
        var patient = _db.Patients.FirstOrDefault(p => p.Id == patientId)
                      ?? throw new ArgumentException("Пациент не найден.");

        MedicalService? service = null;
        if (serviceId.HasValue)
            service = _db.Services.FirstOrDefault(s => s.ServiceId == serviceId.Value)
                      ?? throw new ArgumentException("Услуга не найдена.");

        decimal sum = amount ?? service?.CalculatePrice() ?? 0m;
        if (sum <= 0) throw new ArgumentException("Укажите услугу или сумму оплаты больше нуля.");

        var payment = new Payment { Patient = patient, MedicalServiceId = service?.ServiceId, Amount = sum };
        var (success, message) = payment.MakePayment();
        if (!success) throw new ArgumentException(message);

        _db.Payments.Add(payment);
        _db.SaveChanges();
        return payment;
    }

    public List<Payment> GetPayments()
        => _db.Payments.Include(p => p.Patient).Include(p => p.MedicalService).ToList()
            .OrderByDescending(p => p.PaymentDate).ToList();

    public string RefundPayment(int paymentId)
    {
        var payment = _db.Payments.FirstOrDefault(p => p.PaymentId == paymentId)
                      ?? throw new ArgumentException("Платёж не найден.");
        var (success, message) = payment.RefundPayment();
        if (!success) throw new ArgumentException(message);
        _db.SaveChanges();
        return message;
    }

    // ===================== Статистика =====================

    public PortalStatistics GetStatistics()
    {
        var appointments = _db.Appointments.ToList();
        var payments = _db.Payments.ToList(); // суммы считаем в памяти: SQLite не умеет Sum по decimal

        return new PortalStatistics
        {
            PatientCount = _db.Patients.Count(),
            DoctorCount = _db.Doctors.Count(),
            AppointmentCount = appointments.Count,
            CompletedAppointments = appointments.Count(a => a.Status == AppointmentStatus.Completed),
            ActiveAppointments = appointments.Count(a => a.Status == AppointmentStatus.Scheduled || a.Status == AppointmentStatus.Confirmed),
            CancelledAppointments = appointments.Count(a => a.Status == AppointmentStatus.Cancelled),
            TotalPaid = payments.Where(p => p.PaymentStatus == PaymentStatus.Paid).Sum(p => p.Amount),
            TotalRefunded = payments.Where(p => p.PaymentStatus == PaymentStatus.Refunded).Sum(p => p.Amount)
        };
    }
}
