# UML-диаграмма классов «Медицинский портал»

Картинка: `docs/UML.png` (она же на странице «UML» сайта).

Исходник Mermaid (можно вставить на https://mermaid.live):

```mermaid
classDiagram
direction LR

class Person {
  <<abstract>>
  +int Id
  +string FullName
  +DateTime BirthDate
  #CalculateAge() int
  +DisplayInfo()* void
}
class Patient {
  +int PatientId
  +string PhoneNumber
  +string Email
  +string Address
  +UpdateProfile(fullName, phone, email, address) void
  +GetAge() int
  +DisplayInfo() void
}
class Doctor {
  +int DoctorId
  +string Specialization
  +int Experience
  +int CabinetNumber
  +decimal Salary
  +UpdateSpecialization(spec) void
  +CalculateSalary() decimal
  +CalculatePayment() decimal
  +IsDoctorAvailable(date) bool
  +IsSlotFree(start) bool
  +DisplayInfo() void
}
class IPayable {
  <<interface>>
  +CalculatePayment() decimal
}
class Department {
  +int DepartmentId
  +string DepartmentName
  +int Floor
  +string PhoneNumber
  +Doctor HeadDoctor
  +AddDoctor(doctor) void
  +RemoveDoctor(doctor) void
  +DisplayDoctors() void
}
class MedicalService {
  +int ServiceId
  +string ServiceName
  +string Description
  +decimal Price
  +int Duration
  +CalculatePrice(qty, discount) decimal
  +UpdatePrice(price) void
  +DisplayService() void
}
class Appointment {
  +int AppointmentId
  +DateTime AppointmentDate
  +TimeSpan AppointmentTime
  +AppointmentStatus Status
  +CreateAppointment() bool
  +CancelAppointment() bool
  +ConfirmAppointment() bool
  +DisplayAppointment() void
}
class AppointmentStatus {
  <<enumeration>>
  Scheduled
  Confirmed
  Completed
  Cancelled
}
class MedicalRecord {
  +int RecordId
  +string Diagnosis
  +string MedicalHistory
  +DateTime CreationDate
  +AddDiagnosis(text) void
  +UpdateHistory(note) void
  +DisplayRecord() void
}
class MedicalTest {
  +int TestId
  +string TestName
  +DateTime TestDate
  +string Result
  +AddResult(result) void
  +UpdateResult(result) void
  +DisplayResult() void
}
class Prescription {
  +int PrescriptionId
  +string MedicationName
  +string Dosage
  +int Duration
  +CreatePrescription() void
  +UpdatePrescription(m, d, days) void
  +DisplayPrescription() void
}
class Payment {
  +int PaymentId
  +decimal Amount
  +DateTime PaymentDate
  +PaymentStatus PaymentStatus
  +MakePayment() bool
  +RefundPayment() bool
  +DisplayPayment() void
}
class MedicalPortal {
  -PortalDb _db
  +AddPatient() Patient
  +BookAppointment() Appointment
  +SearchPatients(query) List~Patient~
  +GetStatistics() PortalStatistics
}

Person <|-- Patient : наследование
Person <|-- Doctor : наследование
IPayable <|.. Doctor : реализует
Patient "1" *-- "1" MedicalRecord : композиция
Department "0..1" o-- "0..*" Doctor : агрегация
Department "0..*" --> "0..1" Doctor : HeadDoctor
Patient "1" --> "0..*" Appointment : записи
Doctor "1" --> "0..*" Appointment : приёмы
Appointment "0..*" --> "0..1" MedicalService : услуга
Appointment ..> AppointmentStatus
Patient "1" --> "0..*" MedicalTest : анализы
Patient "1" --> "0..*" Prescription : назначения
Doctor "1" --> "0..*" Prescription : выписывает
Patient "1" --> "0..*" Payment : оплаты
Payment "0..*" --> "0..1" MedicalService : за услугу
MedicalPortal ..> Appointment : управляет данными
```
