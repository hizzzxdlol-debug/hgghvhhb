using MedicalPortalApp.Data;
using MedicalPortalApp.Services;
using Microsoft.EntityFrameworkCore;

// Единый формат чисел и дат (точка в десятичных дробях) для форм и консоли
var culture = System.Globalization.CultureInfo.InvariantCulture;
System.Globalization.CultureInfo.DefaultThreadCurrentCulture = culture;
System.Globalization.CultureInfo.DefaultThreadCurrentUICulture = culture;
System.Globalization.CultureInfo.CurrentCulture = culture;

// Режим консольного меню:  dotnet run -- console
bool consoleMode = args.Contains("console", StringComparer.OrdinalIgnoreCase);
var webArgs = args.Where(a => !a.Equals("console", StringComparison.OrdinalIgnoreCase)).ToArray();

var builder = WebApplication.CreateBuilder(webArgs);

builder.Services.AddControllersWithViews();
builder.Services.AddDbContext<PortalDb>(options =>
    options.UseSqlite(builder.Configuration.GetConnectionString("Default") ?? "Data Source=medicalportal.db"));
builder.Services.AddScoped<MedicalPortal>();

var app = builder.Build();

// Создаём базу SQLite (файл medicalportal.db) и заполняем её тестовыми данными
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<PortalDb>();
    db.Database.EnsureCreated();
    SeedData.Initialize(db);
}

if (consoleMode)
{
    using var scope = app.Services.CreateScope();
    new ConsoleMenu(scope.ServiceProvider.GetRequiredService<MedicalPortal>()).Run();
    return;
}

app.UseStaticFiles();
app.UseRouting();
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
