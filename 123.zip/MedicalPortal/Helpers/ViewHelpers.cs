namespace MedicalPortalApp.Helpers;

public static class ViewHelpers
{
    /// <summary>Значение поля формы после неудачной отправки (чтобы не терять введённые данные).</summary>
    public static string Val(this HttpRequest request, string key, string? fallback = "")
    {
        if (request.HasFormContentType && request.Form.ContainsKey(key))
            return request.Form[key].ToString();
        return fallback ?? string.Empty;
    }
}
